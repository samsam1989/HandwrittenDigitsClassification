import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;

public class hw1{
	public static void hw1(inFile,outFile){
		FileInputStream fis = new FileInputStream(inFile);
		FileWriter writer = new FileWriter(outFile);
		BufferedReader br = new BufferedReader(new InputStreamReader(fis));
		string lines = null;
		while((lines = br.readLine())!=null){
			if(lines.length()>= 26){
				for(int i =0;i=26;i++){
					lines = lines.replace(Lines.charAt(i),"")
				}
				if(lines.length==0)
					writer.write("ture/n");
				else
					writer.write("false/n");
			}
		}
		br.class();
	}
	public class Tester{
		public static void main(string [], args){
		string input = "input.txt";
		string output = "output.txt";
		h1.h1(input,output);
		}
	}
}