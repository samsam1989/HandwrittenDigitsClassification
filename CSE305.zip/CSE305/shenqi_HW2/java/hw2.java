import java.io.FileReader;
import java.io.FileWriter;
import java.util.Stack;

public class hw2{
	public static void hw2(string inptfile,string outptfile){
		FileInputStream reader = new FileCacheImageInputStream(inptfile);
		FileWriter writer = new FileCacheImageOutputStream(outptfile);
		BufferedReader br = new BufferedReader(new InputStreamReader(reader));
		string lines = null;
		Stack t = new Stack();
		while((lines = br.readline())!= null){
			if(lines.length()>1){
				if (lines[0]=="push"){
					if(lines[1]%1 !=0)
						t.push("Error");
					else
						t.push(lines[1])
				}
				else
					if (lines[0]=="quit")
						for(int i =0;i < t.size();i++){
							writer.write(t.pop());
						}
					else if (lines[0] =="pop")
						if (t.size()<1)
							t.push("Error");
						else
							t.pop();
					else if (lines[0]=="Rrror")
							t.push("Error");
					else if (lines[0]=="Ture")
							t.push("Ture");
					else if (lines[0]=="False")
							t.push("False");
					else if (lines[0]=="neg"){
						if(t.size()<1){
							int temp = t.pop();
							int temp = temp * -1;
							t.push(temp);
						}
						else
							t.push("Error");
					}
					else if (lines[0]=="sup"){
						if(t.size()<2)
							t.push("Error");
						else{
							int a = t.pop();
							int b = t.pop();
							int temp = b-a;
							t.push(temp);
						}
					}
					else if(lines[0]=="add"){
						if(t.size()<2)
							t.push("Error")
						else{
							int a = t.pop();
							int b = t.pop();
							int temp = a+b;
							t.push(temp);
						}
					}
					else if(lines[0]=="mul"){
						if(t.size()<2)
							t.push("Error")
						else{
							int a = t.pop();
							int b = t.pop();
							int temp = a*b;
							t.push(temp);
						}
					}
					else if(lines[0]=="div"){
						if(t.size()<2)
							t.push("Error")
						else{
							int a = t.pop();
							int b = t.pop();
							int temp = b/a;
							t.push(temp);
						}
					}
					else if(lines[0]=="rem"){
						if(t.size()<2)
							t.push("Error")
						else{
							int a = t.pop();
							int b = t.pop();
							int temp = b%a;
							t.push(temp);
						}
					}
					else if(lines[0]=="swap"){
						if(t.size()<2)
							t.push("Error")
						else{
							int a = t.pop();
							int b = t.pop();
							int temp = a;
							a = b;
							b = temp;
							t.push(a);
							t.push(b);
						}
					}	
			}
		}
	}
	
}