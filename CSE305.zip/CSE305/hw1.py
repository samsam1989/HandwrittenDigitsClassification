def hw1(input,output):
	with open ("input.txt","r") as file:
		alphabet = "abcdefghijklmnopqrstuvwxzy"
		for line in file :
			if line.len() > 26:
				for char in alphabet:
					if char not in line : 	
						with open ("output.txt","w")as wfile:
							wfile.write("false/n"
					else:
						with open ("output.txt","w")as wfile:
							wfile.write("ture/n")
			else;
				with open("output","w")as wfile:
					wfile.write("false/n")		
						 
