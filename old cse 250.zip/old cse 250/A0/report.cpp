//report.cpp
#include <iostream>
using namespace std;

int main() {
	string my_name="shen Qi"; //edit this
	string my_text_editor ="vi";//edit this
	string my_home_os = "Windows"; //edit this
	bool i_worked = true;          // set to false if you didnt do work

	cout <<"My name is Shen Qi " << my_name <<endl;
	
	if (i_worked) {
		cout <<"I was abble to install and test g++ and "
		     <<"the text editor " << my_text_editor<< '\n'
		     <<"in my home laptop, which runs "
		     << my_home_os << endl;
		      }
	else{
	    cout << "I wasn't able to install and test g++ and/ or a text"
	         << "editor because I dont know " //give a lame reason here
		 << endl;
	    }
	return 0;
}
