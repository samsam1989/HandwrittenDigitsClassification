 //============================================================================
// cmd.cpp
// ~~~~~~~
// author : JOHN DOE
// - implement the two main commands: validate and display
// - this is the only file you can modify and submit
// ============================================================================

#include <iostream>
#include <sstream>
#include <stack>
#include <map>
#include "cmd.h"
#include "Lexer.h" // you should make use of the provided Lexer
#include "term_control.h"
#include "error_handling.h"
using namespace std;

/**
 * -----------------------------------------------------------------------------
 *  TO BE IMPLEMENTED BY YOU
 *  check whether the given expression is well-formed and print it out
 *  - if it is NOT well-formed, return one of the three error messages:
 *     "INVALID TOKEN"
 *     "EXPRESSION NOT WELL-FORMED"
 *     "UNKNOWN TAG"
 *  - if it is well-formed, return the string to be printed, with control codes
 *    inserted properly at the right places 
 * -----------------------------------------------------------------------------
 */
string display(const string& expression) 
{
string a;
string line;
Token tok;
Lexer lexer;
stack <string> tag;
cout <<"Enter an expression ---";
while (getline (cin,line))
{
lexer.set_input(line);
a=line;
cout<<"  -----------  "<<line<<endl;
while (lexer.has_more_token())
{
tok = lexer.next_token();
switch(tok.type)
{
case TAG:
cout<<"TAG  "<<tok.value<<endl;
if(tok.value[0] !='/')
{
tag.push(tok.value);
}
else
{
string temp =tag.top();
if(temp.at(1)==tok.value[2])
{
tag.pop();
if(tag.empty())
return "DISPLAY "+a;
}
}
break;
case IDENT:
cout <<"IDENT: "<<tok.value<<endl;
break;
case BLANK:
cout <<"BLANK: "<<tok.value<<endl;
break;
case ERRTOK:
cout <<"Syntax error on this line\n";
break;
default:
return "EXPRESSION NOT WELL-FORMED";
break;
}
}
return "EXPRESSION NOT WELL-FORMED";
}
    return " ";
}

/**
 * -----------------------------------------------------------------------------
 *  TO BE IMPLEMENTED BY YOU
 *  check whether the given expression is well-formed
 *  - if it is NOT well-formed, return one of the three error messages:
 *     "INVALID TOKEN"
 *     "EXPRESSION NOT WELL-FORMED"
 *     "UNKNOWN TAG"
 *  - if it is well-formed, return "VALID"
 * -----------------------------------------------------------------------------
 */
string validate(const string& expression)
{
string line;
Token tok;
Lexer lexer;
stack <string> tag;
cout <<"Enter an expression ---";
while (getline (cin,line))
{
lexer.set_input(line);
cout<<"  -----------  "<<line<<endl;
while (lexer.has_more_token())
{
tok = lexer.next_token();
switch(tok.type)
{
case TAG:
cout<<"TAG  "<<tok.value<<endl;
if(tok.value[0] !='/')
{
tag.push(tok.value);
}
else
{
string temp =tag.top();
if(temp.at(1)==tok.value[2])
{
tag.pop();
if(tag.empty())
return "VALID";
}
}
break;
case IDENT:
cout <<"IDENT: "<<tok.value<<endl;
break;
case BLANK:
cout <<"BLANK: "<<tok.value<<endl;
break;
case ERRTOK:
cout <<"Syntax error on this line\n";
break;
default:
return "EXPRESSION NOT WELL-FORMED";
break;
}
}
return "EXPRESSION NOT WELL-FORMED";
}
return "VALID";
}

