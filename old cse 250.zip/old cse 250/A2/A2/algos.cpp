// ============================================================================
// algos.cpp
// ~~~~~~~~~~~~~~~~
// author: JOHN DOE
// - this is the ONLY file you can modify
// - feel free to include more headers if you need to
// ============================================================================

#include <stdexcept> // to throw exceptions if you need to
#include <fstream>   // to open & read from input file
#include <cstdlib>   // for atoi() if you want to use it
#include <set>       // for sba algorithm
#include <vector>    // for vba algorithm
#include <algorithm> // for vba algorithm
#include <iostream>
#include <string>
#include "Lexer.h"
#include "algos.h"
using namespace std; // BAD PRACTICE   //istingstream
/////////////////////////////////////////////////////////////////////////
int sba(string filename)
{
    ifstream ifs;
    string Line;
    int edge=0;
    set<pair<int,int> >edgeSet;        
    while (getline(ifs,Line))
    {    
        string temp2=" ";
        string temp3=" ";
	int size =Line.length();
        for(int j=0;j<size;j++)
        {
            if(Line.at(j) != ' ')
            {
                temp2=temp2+Line.at(j);
            }
            else 
            {
                for(int z=j;z<size;z++)
                {
                    temp3=temp3+Line.at(z);
                }
                j=Line.length();
            }
        }   
        int i=atoi(temp2.c_str());
        int j=atoi(temp3.c_str());
        pair<int ,int>p;
        p=make_pair(i,j);
        edgeSet.insert(p);
}
    edge=edgeSet.size();
    return edge;
}
////-------------------------------------------------------------------------///
void printVector(vector<pair<int,int> > & myVec)
  {
            vector<pair<int,int> >::iterator i;
            for(i = myVec.begin();i!=myVec.end();i++)
            {
                cout<<"("<<i->first<<","<<i->second<<")";
            }
            cout<<endl;
  }
////------------------------------------------------------------------------///
int vba(string filename)
{
ifstream ifs;
    string Line;
    int edge=0;
    vector<pair<int,int> > pairVector;
    while (getline(ifs,Line))
    {    
        string temp2=" ";
        string temp3=" ";
	int size=Line.length();
        for(int j=0;j<size;j++)
        {
            if(Line.at(j) != ' ')
            {
                temp2=temp2+Line.at(j);
            }
            else 
            {
                for(int z=j;z<size;z++)
                {
                    temp3=temp3+Line.at(z);
                }
                j=Line.length();
            }
        }   
        int k=atoi(temp2.c_str());
        int j=atoi(temp3.c_str());
        pair<int ,int> p;
        p = make_pair(k,j);
        pairVector.push_back(p);
        cout<<"# of inserted pairs = "<<pairVector.size()<<endl;
	printVector(pairVector);
        sort(pairVector.begin(),pairVector.end());
        printVector(pairVector);
//remove the first duplicate pair that it found 
	vector<pair<int, int> >::iterator i = pairVector.begin();
	while (i != pairVector.end()) {
        vector<pair<int, int> >::iterator j = i+1;
        if (j != pairVector.end() && *j == *i) {
            // remove the pair pointed to by i as a duplicate was found
            i = pairVector.erase(i);
            break;
        }        
    }
        printVector(pairVector);
    }
	edge=pairVector.size();
        return edge; 
}

/////////////////////////////////////////////////////////////////////////


			

