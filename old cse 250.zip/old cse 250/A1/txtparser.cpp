#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	string fname, line;
	ifstream ifs;
	int col,row;
	cout << "---------Enter a file name :";
	while(getline(cin,fname)){
		if(fname=="exit") {
                	cout <<"exit out of the file"<<endl;
			return 0;
			}
		ifs.open(fname.c_str());
		if(ifs.fail()){
			cerr<<"ERROR: Failed to open file " <<fname<<endl;
			ifs.clear();
		}
		else{
			row=0;
			while(getline(ifs, line)){
				col=0;
				string temp[line.length()];
				for(int i=0;i<line.length();i++){
					temp[i]=line.at(i);
				}
				cout<<temp<<endl;
				for(int j=0;j<line.length()-1;j++){
					if(temp[j]==" " && temp[j+1]!=" ")
					col++;
				}
			cout<<"line"<<row++<<" ; "<<"cow"<<col<<" ; "<<endl;
			}
			ifs.close();
		}
		cout<<"-----------Enter another file name:";
	}
	return 0;
}		
