#include<iostream>
#include<vector>
#include<algorithm>
#include<fstream>

using namespace std;

int main(int agrc,char *argv[])
{
 
 ifstream readin;
 int minim = 0;
 int maxim = 0;
 int median= 0;

 //read the file foo
 
 readin.open(argv[1]);   
 // if the file doesnt open will cout Error
 if(!readin)
 {
  cout<<"Error"<<endl;
  return 0;
 }

 // file open 
 vector <int> v;
 int a;
 while(readin >> a)
 {
 // int temp;
 // getline(readin,temp);
 // readin >> temp;
  v.push_back(a);
 }
 // Find the Maxim  // Find the Minim
 maxim = v[0];
 minim = v[0];
 size_t size = v.size();
 for (size_t i =0 ; i < size ;i++)
 {
  if(v[i] > maxim)
   maxim = v[i];
  if(v[i] < minim)
   minim = v[i];
 }
 // Find the Median 
 sort(v.begin(),v.end());
 if(size % 2 == 0)
  median = (v[size /2 - 1] + v[size / 2] / 2);
 else 
  median = v[size / 2];

 cout<<minim<<" "<<median<<" "<<maxim<<endl;
 
 return 0;
}




































