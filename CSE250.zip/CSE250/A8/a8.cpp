#include <iostream>
#include <map>
#include <string>

using namespace std;

int main(int agc,char* agv[]){

}
