#include <iostream>
#include <string>
using namespace std;
int main(){
	string name = "Shen Qi";
	bool has_tested = false;
	int num_tests = 1;
	cout<< name;
	if(has_tested){
		cout<<"performed "<<num_tests<<"test(s) "<<endl;
	}
	else{
		cout<<" was lazy"<<endl;
	}
	return 0;
}
