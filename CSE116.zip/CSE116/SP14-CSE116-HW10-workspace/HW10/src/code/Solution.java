package code;

public class Solution {

	public String question1() {
		return "a(6):a(6)";
	}

	public String question2() {
		return "a(6):a(3)";
	}

}
