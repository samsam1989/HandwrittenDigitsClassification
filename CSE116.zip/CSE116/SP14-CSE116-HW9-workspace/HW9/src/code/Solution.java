package code;

public class Solution {

	public String question1() {
		return "abc";
	}

	public String question2() {
		return "(0,a)(0,b)(1,a)(1,b)(2,a)(2,b)";
	}

}
