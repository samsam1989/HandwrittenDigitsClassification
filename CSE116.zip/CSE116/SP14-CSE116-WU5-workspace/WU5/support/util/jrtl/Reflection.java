package util.jrtl;

import java.lang.reflect.Method;
import java.util.List;

public class Reflection {

	public static List<Method> getMethodsBySignature(Class<?> type, Class<?> ret, Class<?>... args){
		
		return null;
	}
	
	public static List<Method> getMethodsByName(Class<?> type, String name){
		
		return null;
	}
	
	
}
