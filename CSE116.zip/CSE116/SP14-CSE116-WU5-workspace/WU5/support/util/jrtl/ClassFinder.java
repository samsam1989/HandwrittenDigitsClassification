package util.jrtl;

public interface ClassFinder {

	public boolean matches(DynamicType c);
	
}
