package code;

import java.util.HashMap;

import util.general.CharacterFromFileReader;

public class WriteUp {
public HashMap<String,Integer> added(String a){
	HashMap<String,Integer>  b =new HashMap<String,Integer>();
	CharacterFromFileReader read =new CharacterFromFileReader(a);
	String i="";
	int state =0;
	while (read.hasNext()){
		char c=read.next();
		switch(state){
		case 0:
			if(c=='{'){
				state=1;
				break;
			}
		case 1:
			if(c=='A'){
				state=2;
				break;
			}
			else{
				state =0;
				break;
			}
		case 2:
			if(c=='}'){
				state =3;
				break;
			}
			else{
				state=1;
				break;
			}
		case 3:
			if(c=='{'){
				state =4;
				break;
			}
			else{
				i=i+c;
				break;
			}
		case 4:
			if(c=='a'){
				state =5;
				break;
			}
			else{
				i=i+c;
				break;
			}
		case 5:
			if(c=='}'){
				if(b.containsKey(i)){
					b.put(i,b.get(i)+1);
				}
				else
					b.put(i,1);
				i="";
				state =0;
				break;
			}
			else{
				i=i+c;
				break;
			}
		}
	}
	return b;	
}
}
